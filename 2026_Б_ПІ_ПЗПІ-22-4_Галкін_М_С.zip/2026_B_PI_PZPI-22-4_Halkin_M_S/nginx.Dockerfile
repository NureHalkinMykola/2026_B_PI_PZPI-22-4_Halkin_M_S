FROM nginx:1.27.0-alpine

USER root

RUN chown -R 101:101 /var/cache/nginx \
    && chown -R 101:101 /var/log/nginx \
    && chown -R 101:101 /etc/nginx \
    && touch /var/run/nginx.pid \
    && chown 101:101 /var/run/nginx.pid

USER 101:101