#!/bin/bash

DOCKER=$(which docker)
[ -z "$DOCKER" ] && DOCKER="/usr/bin/docker"

CONTAINER_NAME="backend"
THRESHOLD=88

USAGE=$(df / | grep / | awk '{ print $5 }' | sed 's/%//')

if [ "$USAGE" -gt "$THRESHOLD" ]; then
    "$DOCKER" compose stop "$CONTAINER_NAME"
else
    "$DOCKER" compose start "$CONTAINER_NAME"
fi