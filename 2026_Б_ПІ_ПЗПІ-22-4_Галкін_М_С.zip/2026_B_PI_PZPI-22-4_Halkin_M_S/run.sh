#!/bin/bash
APP_UID=900
APP_GID=900
DB_UID=999
DB_GID=999
SSL_UID=200
SSL_GID=200

UPLOADS_DIRS=("./uploads" "./uploads-temp")
DB_DIR="./db"
SSL_DIR="./certs"

echo "--- Setting up secure permissions ---"

for dir in "${UPLOADS_DIRS[@]}"; do
    mkdir -p "$dir"
    sudo chown -R $APP_UID:$APP_GID "$dir"
    sudo chmod -R 775 "$dir"
    echo "Set $dir to $APP_UID:$APP_GID"
done

mkdir -p "$DB_DIR"
sudo chown -R $DB_UID:$DB_GID "$DB_DIR"
sudo chmod -R 775 "$DB_DIR"
echo "Set $DB_DIR to $DB_UID:$DB_GID"

mkdir -p "$SSL_DIR"
sudo chown -R $SSL_UID:$SSL_GID "$SSL_DIR"
sudo chmod -R 775 "$SSL_DIR"
echo "Set $SSL_DIR to $SSL_UID:$SSL_GID"

if ! id "ssl-user" &>/dev/null; then
    sudo useradd -u 200 -s /bin/sh ssl-user
fi

sudo chown $SSL_UID:$SSL_UID "$SSL_DIR"

echo "Generating certificates as ssl-user..."
sudo -u ssl-user openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout "$SSL_DIR/selfsigned.key" \
    -out "$SSL_DIR/selfsigned.crt" \
    -subj '/C=UA/ST=Kharkiv/L=Kharkiv/O=Dev/CN=dblab-software.nure.ua'

sudo chown $SSL_UID:101 "$SSL_DIR/selfsigned.key" "$SSL_DIR/selfsigned.crt"
sudo chmod 640 "$SSL_DIR/selfsigned.key" "$SSL_DIR/selfsigned.crt"

APP_PATH="$(pwd)"
SERVICE_FILE="/etc/systemd/system/storage-task.service"
TIMER_FILE="/etc/systemd/system/storage-task.timer"

cat <<EOF | sudo tee $SERVICE_FILE
[Unit]
Description=Run storage maintenance

[Service]
Type=oneshot
User=root
WorkingDirectory=$APP_PATH
ExecStart=$APP_PATH/storage.sh
EOF

cat <<EOF | sudo tee $TIMER_FILE
[Unit]
Description=Run storage maintenance every 5 minutes

[Timer]
OnBootSec=1min
OnUnitActiveSec=5min

[Install]
WantedBy=timers.target
EOF

cat <<EOF | sudo tee /etc/systemd/system/db-backup.service
[Unit]
Description=Database and Files Weekly Backup

[Service]
Type=oneshot
User=root
WorkingDirectory=$APP_PATH
EnvironmentFile=$APP_PATH/.env
ExecStart=/bin/bash -c "mkdir -p $APP_PATH/db-backups/uploads && \
  /usr/bin/docker exec my-db mysqldump --no-tablespaces --default-character-set=utf8mb4 -u\$DB_USER -p\$DB_PASSWORD \$DB_NAME > $APP_PATH/db-backups/backup_latest.sql && \
  cp -r $APP_PATH/uploads/* $APP_PATH/db-backups/uploads/"
EOF

cat <<EOF | sudo tee /etc/systemd/system/db-backup.timer
[Unit]
Description=Weekly DB Backup
[Timer]
OnCalendar=weekly
Persistent=true
[Install]
WantedBy=timers.target
EOF

sudo chmod 644 $SERVICE_FILE $TIMER_FILE
sudo systemctl daemon-reload
sudo systemctl enable --now storage-task.timer
sudo systemctl enable --now db-backup.timer

echo "--- Systemd timer active ---"

echo "--- Permissions applied. Starting containers... ---"
docker compose up -d --build