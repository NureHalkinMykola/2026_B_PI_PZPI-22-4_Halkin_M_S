const express = require('express');
const app = express();
const db = require('./config/db.config.js');
const Relations = require("./models/Relations.js");
const cors = require('cors');
const bcrypt = require('bcryptjs');
const { User } = require('./models/Relations.js');

const PORT = process.env.PORT || 5002;

const chapterRoutes = require('./routes/chapter.js');
const developmentDirectionRoutes = require('./routes/developmentDirection.js');
const disciplineRoutes = require('./routes/discipline.js');
const disciplineSkillRoutes = require('./routes/disciplineSkill.js');
const disciplineTeacherRoutes = require('./routes/disciplineTeacher.js');
const eventRoutes = require('./routes/event.js');
const languageRoutes = require('./routes/language.js');
const lessonRoutes = require('./routes/lesson.js');
const levelRoutes = require('./routes/level.js');
const materialRoutes = require('./routes/material.js');
const skillRoutes = require('./routes/skill.js');
const skillChapterRoutes = require('./routes/skillChapter.js');
const teacherRoutes = require('./routes/teacher.js');
const userRoutes = require('./routes/user.js');
const authRoutes = require('./routes/auth.js');
const resourceRoutes = require('./routes/resource.js');
const interactionUserResourceRoutes = require('./routes/interaction_user_resource.js')
const commentRoutes = require('./routes/comment.js')
const linkTypeRoutes = require('./routes/linkType.js');
const stackRoutes = require('./routes/stack.js');
const interactionUserStackRoutes = require('./routes/interaction_user_stack.js');

const directionRoutes = require('./routes/direction.js');
const proposalTypeRoutes = require('./routes/proposalType.js');
const proposalRoutes = require('./routes/proposal.js');
const workRoutes = require('./routes/work.js');
const resultTypeRoutes = require('./routes/resultType.js');
const magazineRoutes = require('./routes/magazine.js');
const conferenceRoutes = require('./routes/conference.js');
const competitionRoutes = require('./routes/competition.js');
const resultRoutes = require('./routes/result.js');
const statisticsRoutes = require('./routes/statistics.js');
const reportRoutes = require('./routes/report.js');

const projectRoutes = require('./routes/project.js');
const modelRoutes = require('./routes/dataModel.js');
const expertiseRoutes = require('./routes/expertise.js');
const imbedRoutes = require('./routes/imbed.js');
const projectCommentRoutes = require('./routes/projectComment.js');
const expertRequestRoutes = require('./routes/expertRequest.js');

const storageRoutes = require('./routes/storage.js');


app.use(cors());
app.use(express.json({ limit: '10mb' }));

app.use('/chapter', chapterRoutes);
app.use('/developmentDirection', developmentDirectionRoutes);
app.use('/discipline', disciplineRoutes);
app.use('/disciplineSkill', disciplineSkillRoutes);
app.use('/disciplineTeacher', disciplineTeacherRoutes);
app.use('/event', eventRoutes);
app.use('/language', languageRoutes);
app.use('/lesson', lessonRoutes);
app.use('/level', levelRoutes);
app.use('/material', materialRoutes);
app.use('/skill', skillRoutes);
app.use('/skillChapter', skillChapterRoutes);
app.use('/teacher', teacherRoutes);
app.use('/user', userRoutes);
app.use('/auth', authRoutes);
app.use('/resource', resourceRoutes);
app.use('/interactionUserResource', interactionUserResourceRoutes);
app.use('/comment', commentRoutes);
app.use('/linkType', linkTypeRoutes);
app.use('/stack', stackRoutes);
app.use("/interactionUserStack", interactionUserStackRoutes);

app.use('/direction', directionRoutes);
app.use('/proposalType', proposalTypeRoutes);
app.use('/proposal', proposalRoutes);
app.use('/work', workRoutes);
app.use('/resultType', resultTypeRoutes);
app.use('/magazine', magazineRoutes);
app.use('/conference', conferenceRoutes);
app.use('/competition', competitionRoutes);
app.use('/result', resultRoutes);
app.use('/statistics', statisticsRoutes);
app.use('/report', reportRoutes);

app.use('/project', projectRoutes);
app.use('/model', modelRoutes);
app.use('/expertise', expertiseRoutes);
app.use('/imbed', imbedRoutes);
app.use('/projectComment', projectCommentRoutes);
app.use('/expertRequest', expertRequestRoutes);

app.use('/storage', storageRoutes);

const createAdminUser = async () => {
    try {
        const adminLogin = 'admin';

        const existingAdmin = await User.findOne({ where: { role: "admin" } });

        if (!existingAdmin) {
            console.log('Initializing admin user...');

            const hashedPassword = await bcrypt.hash(process.env.INIT_ADMIN_PASSWORD, 10);

            await User.create({
                login: adminLogin,
                email: 'admin@nure.ua',
                password: hashedPassword,
                role: 'admin',
                nickname: 'Administrator'
            });

            console.log('Admin user created successfully.');
        } else {
            console.log('Admin user already exists. Skipping initialization.');
        }
    } catch (error) {
        console.error('Error during admin initialization:', error);
    }
};

db.sequelize.sync()
    .then(async () => {
        console.log('Database connected');

        await createAdminUser();

        app.listen(PORT, () => {
            console.log(`Server running on port ${PORT}`);
        });
    })
    .catch(err => console.error('Failed to sync models:', err));

module.exports = app;