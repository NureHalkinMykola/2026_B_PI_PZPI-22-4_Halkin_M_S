#!/bin/bash
MY_UID=$(id -u)
MY_GID=$(id -g)

DIRS=("./uploads" "./uploads-temp" "./db" "./certs" "./db-backups")
FILES=("./storage.sh")

echo "--- Starting full teardown and cleanup ---"

docker compose down -v

for dir in "${DIRS[@]}"; do
    if [ -d "$dir" ]; then
        sudo chown -R $MY_UID:$MY_GID "$dir"
        sudo chmod -R 775 "$dir"
    fi
done

for file in "${FILES[@]}"; do
    if [ -f "$file" ]; then
        sudo chown $MY_UID:$MY_GID "$file"
        sudo chmod 755 "$file"
    fi
done

if id "ssl-user" &>/dev/null; then
    sudo userdel -r ssl-user
fi

echo "--- Removing all systemd timers ---"

sudo systemctl stop storage-task.timer db-backup.timer
sudo systemctl disable storage-task.timer db-backup.timer

sudo rm /etc/systemd/system/storage-task.service
sudo rm /etc/systemd/system/storage-task.timer
sudo rm /etc/systemd/system/db-backup.service
sudo rm /etc/systemd/system/db-backup.timer

sudo systemctl daemon-reload
sudo systemctl reset-failed

echo "--- Cleanup complete. ---"